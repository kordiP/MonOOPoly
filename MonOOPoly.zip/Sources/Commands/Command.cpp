#include "../../Headers/Commands/Command.h"

Command::Command() : data(GameData::getInstance()) { }
