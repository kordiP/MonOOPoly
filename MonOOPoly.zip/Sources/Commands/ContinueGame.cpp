#include "../../Headers/Commands/ContinueGame.h"

void ContinueGame::execute() const
{
	throw std::logic_error("Sorry, this is not ready yet.");
}
