#pragma once

class Colors
{
public:
	static const int DEFAULT_COLOR = 0 + 16 * 0;
};